const x = 10;
console.log(x);

// iteraciones 
const cielo = document.getElementById("cielo");

for(let i = 0; i < 5; i++){
    cielo.innerHTML += '⭐';
}